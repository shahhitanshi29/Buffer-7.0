import java.util.HashMap;
public class Vendor {
    String vendor_name;
    HashMap<String,Integer> menu = new HashMap<>();
    int start_time;
    Node head;
    Node tail;
    Node current_stop;
    Queue pending_orders = new Queue();
    Queue ready_orders = new Queue();
    ReviewStack reviews = new ReviewStack();
    Wallet wallet;
    boolean reached;
    boolean isClosed;

    Vendor(String name, int start) {
        vendor_name = name;
        start_time = start;
        head = null;
        tail = null;
        current_stop = null;
        reached = true;
        isClosed = false;
        wallet = new Wallet(name, 0);
    }

    void add_menuItem(String item, int price) {
        menu.put(item, price);
    }

    void add_stop(String location, int st, int ttr) {
        Node newnode = new Node(location, st, ttr);
        if (head == null) {
            head = newnode;
            newnode.next = newnode;
            tail = newnode;
            current_stop = newnode;
        } else {
            tail.next = newnode;
            newnode.next = head;
            tail = newnode;
        }
    }

    // FIX: transit() now advances the pointer AND sets reached=false.
    void transit() {
        if (current_stop != null) {
            current_stop = current_stop.next;
            reached = false;
        }
    }

    // FIX: move() (reach) now only confirms arrival — no pointer advance.
    void move() {
        reached = true;
    }

    // NEW: End Day Early
    void end_day() {
        isClosed = true;
    }

    void take_order(Order o, boolean choice) {
        if (o.status.equals("PENDING")) {
            if (choice) {
                o.status = "ACCEPTED";
                pending_orders.add_order(o);
            } else {
                o.status = "DECLINED";
            }
        }
    }

    void food_ready(Order o) {
        o.status = "READY";
        pending_orders.remove_order(o);
        ready_orders.add_order(o);
    }

    void order_collected(Order o) {
        o.status = "COLLECTED";
        ready_orders.remove_order(o);
    }

    String getStatus() {
        if (isClosed) return "CLOSED";
        if (current_stop == null) return "No route set";
        if (reached) {
            return "Selling at: " + current_stop.location_name +
                   " | Next stop: " + current_stop.next.location_name;
        } else {
            return "In transit to: " + current_stop.location_name;
        }
    }
}