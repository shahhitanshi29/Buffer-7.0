import java.util.HashMap;
public class Vendor {
    String vendor_name;
    HashMap<String,Integer> menu = new HashMap<>();
    int start_time;
    Node head;
    Node tail;
    Node current_stop;
    Queue pending_orders = new Queue();
    Queue ready_orders = new Queue();
    ReviewStack reviews = new ReviewStack();
    Wallet wallet;
    boolean reached;

    Vendor(String name, int start) {
        vendor_name = name;
        start_time = start;
        head = null;
        tail = null;
        current_stop = null;
        reached = true;
        wallet = new Wallet(name, 0);
    }

    void add_menuItem(String item, int price) {
        menu.put(item, price);
    }

    void add_stop(String location, int st, int ttr) {
        Node newnode = new Node(location, st, ttr);
        if (head == null) {
            head = newnode;
            newnode.next = newnode;
            tail = newnode;
            current_stop = newnode;
        } else {
            tail.next = newnode;
            newnode.next = head;
            tail = newnode;
        }
    }

    void move() {
        if (current_stop != null) {
            current_stop = current_stop.next;
            reached = true;
        }
    }

    void transit() {
        reached = false;
    }

    void take_order(Order o, boolean choice) {
        if (o.status.equals("PENDING")) {
            if (choice) {
                o.status = "ACCEPTED";
                pending_orders.add_order(o);
            } else {
                o.status = "DECLINED";
            }
        }
    }

    void food_ready(Order o) {
        o.status = "READY";
        pending_orders.remove_order(o);
        ready_orders.add_order(o);
    }

    void order_collected(Order o) {
        o.status = "COLLECTED";
        ready_orders.remove_order(o);
    }

    String getStatus() {
        if (current_stop == null) return "No route set";
        if (reached) {
            return "Selling at: " + current_stop.location_name +
                   " | Next stop: " + current_stop.next.location_name;
        } else {
            return "In transit to: " + current_stop.next.location_name;
        }
    }
}
