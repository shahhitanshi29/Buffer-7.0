// ═══════════════════════════════════════════════════════════════════
//  Vendor Vantage — script.js   (fully integrated with Java backend)
// ═══════════════════════════════════════════════════════════════════
const API = "http://localhost:8080/api";

// ── Shared helpers ────────────────────────────────────────────────
async function apiFetch(url, options = {}) {
    try {
        const res = await fetch(url, {
            ...options,
            headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
        });
        return await res.json();
    } catch (err) {
        console.error("API error:", url, err);
        return null;
    }
}

function getUser()    { return JSON.parse(localStorage.getItem('currentUser') || 'null'); }
function setUser(obj) { localStorage.setItem('currentUser', JSON.stringify(obj)); }

function showAlert(icon, title, msg) {
    const m = document.getElementById('alertModal');
    if (!m) { alert(title + '\n' + msg); return; }
    document.getElementById('alertIcon').innerText  = icon;
    document.getElementById('alertTitle').innerText = title;
    document.getElementById('alertMsg').innerText   = msg;
    m.style.display = 'flex';
}
function closeAlert() {
    const m = document.getElementById('alertModal');
    if (m) m.style.display = 'none';
}

// ── Gateway (index.html) ──────────────────────────────────────────
const customerCard = document.getElementById('customerCard');
const vendorCard   = document.getElementById('vendorCard');
if (customerCard) customerCard.onclick = () => window.location.href = 'customer-auth.html';
if (vendorCard)   vendorCard.onclick   = () => window.location.href = 'vendor-auth.html';

// ── Vendor Auth (vendor-auth.html) ────────────────────────────────
function showErr(id, msg)  { const el = document.getElementById(id); el.innerText = msg; el.style.display = ''; }
function hideErr(id)       { document.getElementById(id).style.display = 'none'; }

const loginBtn = document.getElementById('loginBtn');
if (loginBtn) {
    loginBtn.onclick = async () => {
        const key = document.getElementById('loginKey').value.trim().toLowerCase();
        const pw  = document.getElementById('loginPw').value;
        if (!key || !pw) { showErr('loginError', 'Please enter vendor key and password.'); return; }
        hideErr('loginError');

        const data = await apiFetch(`${API}/vendor/login`, {
            method: 'POST',
            body: JSON.stringify({ key, password: pw })
        });

        if (!data || data.error) {
            showErr('loginError', data ? data.error : 'Server not reachable. Is java Server running?');
            return;
        }
        setUser({ name: data.name, bizName: data.name, type: 'vendor', vendorKey: key });
        window.location.href = 'vendor-dashboard.html';
    };
}

const regBtn = document.getElementById('regBtn');
if (regBtn) {
    regBtn.onclick = async () => {
        const name = document.getElementById('regName').value.trim();
        const pw   = document.getElementById('regPw').value.trim();
        if (!name)       { showErr('regError', 'Business name is required.');      return; }
        if (pw.length < 4){ showErr('regError', 'Password must be at least 4 chars.'); return; }
        hideErr('regError');

        // Collect stops
        const stops = [];
        document.querySelectorAll('.stop-row').forEach(row => {
            const n = row.querySelector('.stop-name').value.trim();
            const s = parseInt(row.querySelector('.stop-stay').value)   || 15;
            const t = parseInt(row.querySelector('.stop-travel').value) || 10;
            if (n) stops.push({ name: n, stay: s, travel: t });
        });
        if (stops.length === 0) { showErr('regError', 'Add at least one stop.'); return; }

        // Collect menu
        const menu = {};
        document.querySelectorAll('.menu-row').forEach(row => {
            const item  = row.querySelector('.menu-name').value.trim();
            const price = parseInt(row.querySelector('.menu-price').value) || 0;
            if (item && price > 0) menu[item] = price;
        });
        if (Object.keys(menu).length === 0) { showErr('regError', 'Add at least one menu item.'); return; }

        const data = await apiFetch(`${API}/vendor/register`, {
            method: 'POST',
            body: JSON.stringify({ name, password: pw, stops, menu })
        });

        if (!data || data.error) {
            showErr('regError', data ? data.error : 'Server not reachable.');
            return;
        }

        const sEl = document.getElementById('regSuccess');
        sEl.innerText = `Registered! Your key: "${data.key}" — use it to login.`;
        sEl.style.display = '';
        setTimeout(() => {
            setUser({ name: data.name, bizName: data.name, type: 'vendor', vendorKey: data.key });
            window.location.href = 'vendor-dashboard.html';
        }, 1800);
    };
}

// ── Customer Auth (customer-auth.html) ────────────────────────────
const custLoginBtn = document.getElementById('custLoginBtn');
if (custLoginBtn) {
    custLoginBtn.onclick = () => {
        const name = document.getElementById('custName').value.trim();
        if (!name) {
            const el = document.getElementById('custError');
            if (el) { el.innerText = 'Please enter your name.'; el.style.display = ''; }
            return;
        }
        setUser({ name, type: 'customer' });
        window.location.href = 'dashboard.html';
    };
}

// ── Customer Dashboard (dashboard.html) ───────────────────────────
const vendorGrid  = document.getElementById('vendorGrid');
const searchInput = document.getElementById('foodSearch');

async function renderVendors(keyword = '') {
    if (!vendorGrid) return;
    vendorGrid.innerHTML = "<p style='color:#888;padding:20px'>Loading vendors...</p>";
    const url = keyword.trim()
        ? `${API}/search?q=${encodeURIComponent(keyword)}`
        : `${API}/vendors`;
    const vendors = await apiFetch(url);
    vendorGrid.innerHTML = '';
    if (!vendors || vendors.length === 0) {
        vendorGrid.innerHTML = `<p style='color:#888;padding:20px'>No vendors found${keyword ? ' for "'+keyword+'"' : ''}.</p>`;
        return;
    }
    vendors.forEach(v => {
        const menuItems = Object.keys(v.menu || {});
        const statusFlag = v.status === 'ON-SITE'
            ? `<span class="status-flag on-site">● Cooking & Selling</span>`
            : `<span class="status-flag in-transit">🚚 In-Transit</span>`;
        const locationPill = v.status === 'ON-SITE'
            ? `<p class="current-stop">📍 At: <b>${v.currentStop}</b></p>`
            : `<p class="current-stop">🚀 Heading to: <b>${v.nextStop}</b></p>`;
        const rating = parseFloat(v.rating) > 0 ? v.rating : 'New';
        const menuJson = JSON.stringify(v.menu || {}).replace(/'/g, "\\'");

        vendorGrid.innerHTML += `
            <div class="vendor-card">
                <div class="vendor-img" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center;font-size:3rem;position:relative">
                    🍽️
                    <div class="rating-badge">⭐ ${rating}</div>
                </div>
                <div class="vendor-info">
                    <h3>${v.name}</h3>
                    <div class="menu-tags">
                        ${menuItems.map(item => `<span>${item} ₹${v.menu[item]}</span>`).join('')}
                    </div>
                    <div class="status-section">
                        <div class="location-display">${locationPill}${statusFlag}</div>
                        <div class="next-stop-preview">Next: <b>${v.nextStop}</b></div>
                    </div>
                    <button onclick='openOrderModal("${v.name}","${v.key}",${menuJson})'
                        style="margin-top:14px;background:#ff9f43;color:black;border:none;padding:11px 20px;border-radius:8px;font-weight:bold;cursor:pointer;width:100%;font-family:Poppins,sans-serif">
                        🛒 Pre-Order
                    </button>
                </div>
            </div>`;
    });
}

async function refreshWalletDisplay() {
    const user = getUser();
    if (!user) return;
    const data = await apiFetch(`${API}/wallet/balance?customer=${encodeURIComponent(user.name)}`);
    if (!data) return;
    const el = document.getElementById('sidebarWallet');
    if (el) el.innerText = data.balance;
}

async function topupWallet() {
    const user = getUser();
    if (!user) return;
    const data = await apiFetch(`${API}/wallet/topup`, {
        method: 'POST',
        body: JSON.stringify({ customer: user.name, amount: 200 })
    });
    if (data) {
        const el = document.getElementById('sidebarWallet');
        if (el) el.innerText = data.balance;
        showAlert('💰', 'Wallet Topped Up', '+₹200 added to your wallet!\nNew balance: ₹' + data.balance);
    }
}

function showDashTab(tab, el) {
    ['vendors','myorders','reviews'].forEach(t => {
        document.getElementById('tab-'+t).style.display = t === tab ? '' : 'none';
    });
    document.querySelectorAll('.side-nav a').forEach(a => a.classList.remove('active'));
    if (el) el.classList.add('active');
    if (tab === 'myorders')  loadMyOrders();
    if (tab === 'reviews')   loadReviewVendors();
}

// ── ORDER MODAL ───────────────────────────────────────────────────
let currentCart = {}, currentVendorKey = '', currentMenu = {};

function openOrderModal(vendorName, vendorKey, menu) {
    currentCart = {}; currentVendorKey = vendorKey; currentMenu = menu;
    document.getElementById('modalVendorName').innerText = `Order from ${vendorName}`;
    document.getElementById('orderLocation').value = '';
    const list = document.getElementById('menuItemsList');
    list.innerHTML = '';
    Object.entries(menu).forEach(([item, price]) => {
        const safeId = item.replace(/[^a-zA-Z0-9]/g,'_');
        list.innerHTML += `
            <div class="menu-item-row">
                <span>${item}</span>
                <span style="color:#ff9f43;font-weight:600">₹${price}</span>
                <div class="qty-control">
                    <button class="qty-btn" onclick="changeQty('${item}',-1)">−</button>
                    <span class="qty-display" id="qty-${safeId}">0</span>
                    <button class="qty-btn" onclick="changeQty('${item}',1)">+</button>
                </div>
            </div>`;
    });
    updateCartSummary();
    document.getElementById('orderModal').style.display = 'flex';
}

function changeQty(item, delta) {
    currentCart[item] = Math.max(0, (currentCart[item] || 0) + delta);
    if (currentCart[item] === 0) delete currentCart[item];
    const safeId = item.replace(/[^a-zA-Z0-9]/g,'_');
    const el = document.getElementById('qty-'+safeId);
    if (el) el.innerText = currentCart[item] || 0;
    updateCartSummary();
}

function updateCartSummary() {
    const summary = document.getElementById('cartSummary');
    const entries = Object.entries(currentCart);
    if (!summary) return;
    if (entries.length === 0) { summary.style.display = 'none'; return; }
    summary.style.display = '';
    let total = 0;
    document.getElementById('cartItems').innerHTML = '';
    entries.forEach(([item, qty]) => {
        const price = currentMenu[item] * qty;
        total += price;
        document.getElementById('cartItems').innerHTML +=
            `<div class="cart-row"><span>${item} × ${qty}</span><span>₹${price}</span></div>`;
    });
    document.getElementById('cartTotal').innerText   = '₹' + total;
    document.getElementById('tokenDeposit').innerText = Math.floor(total / 4);
}

function closeOrderModal() { document.getElementById('orderModal').style.display = 'none'; }

async function submitOrder() {
    const user = getUser();
    if (!user) { showAlert('⚠️','Not Logged In','Please login first.'); return; }
    const location = document.getElementById('orderLocation').value.trim();
    if (!location) { showAlert('⚠️','Location Missing','Please enter your pickup location.'); return; }
    const items = [];
    Object.entries(currentCart).forEach(([item, qty]) => { for (let i = 0; i < qty; i++) items.push(item); });
    if (items.length === 0) { showAlert('⚠️','Empty Cart','Please select at least one item.'); return; }

    const result = await apiFetch(`${API}/order/place`, {
        method: 'POST',
        body: JSON.stringify({ vendor: currentVendorKey, customer: user.name, location, items })
    });
    closeOrderModal();

    if (!result) { showAlert('❌','Server Error','Make sure java Server is running on port 8080.'); return; }
    if (!result.valid) { showAlert('❌','Invalid Items','Some items are not on this vendor\'s menu.'); return; }

    // Save order to local history
    const history = JSON.parse(localStorage.getItem('orderHistory') || '[]');
    history.unshift({ orderId: result.orderId, vendorKey: currentVendorKey, status: result.status, bill: result.bill, items });
    localStorage.setItem('orderHistory', JSON.stringify(history.slice(0,20)));

    refreshWalletDisplay();
    showAlert('✅','Order Placed!',
        `Bill: ₹${result.bill}\nToken deposit locked: ₹${Math.floor(result.bill/4)}\nOrder ID: ${result.orderId.substring(0,12)}...\nWallet: ₹${result.walletBalance}`);
}

// ── MY ORDERS TAB ─────────────────────────────────────────────────
async function loadMyOrders() {
    const list = document.getElementById('myOrdersList');
    if (!list) return;
    const history = JSON.parse(localStorage.getItem('orderHistory') || '[]');
    if (history.length === 0) {
        list.innerHTML = "<p style='color:#888'>No orders yet. Go to Live Stalls to order!</p>"; return;
    }
    list.innerHTML = "<p style='color:#888;margin-bottom:12px'>Fetching latest status...</p>";
    let html = '';
    for (const h of history) {
        const data = await apiFetch(`${API}/order/status?id=${h.orderId}`);
        const status = data ? data.status : h.status;
        const bill   = data ? data.bill   : h.bill;
        html += `
            <div class="my-orders-card">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <span style="color:#ff9f43;font-size:0.85rem">#${h.orderId.substring(0,12)}...</span>
                    <span class="order-status-pill pill-${status}">${status}</span>
                </div>
                <div style="color:white;margin:6px 0">${h.items.join(', ')}</div>
                <div style="color:#2ecc71;font-weight:600">₹${bill}</div>
                ${status === 'READY' ? `<button class="collect-btn" onclick="collectOrder('${h.orderId}','${h.vendorKey}')">✅ I\'ve collected my order</button>` : ''}
            </div>`;
    }
    list.innerHTML = html;
}

async function collectOrder(orderId, vendorKey) {
    const result = await apiFetch(`${API}/order/collect`, {
        method: 'POST',
        body: JSON.stringify({ vendor: vendorKey, orderId })
    });
    if (result) {
        showAlert('✅','Collected!','Your order has been marked as collected. Enjoy your food!');
        refreshWalletDisplay();
        loadMyOrders();
    }
}

// ── REVIEWS TAB ───────────────────────────────────────────────────
async function loadReviewVendors() {
    const sel = document.getElementById('reviewVendorKey');
    if (!sel) return;
    const vendors = await apiFetch(`${API}/vendors`);
    sel.innerHTML = '';
    if (vendors) vendors.forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.key; opt.innerText = v.name;
        sel.appendChild(opt);
    });
}

// Star rating
document.querySelectorAll('.star').forEach(star => {
    star.onclick = () => {
        const val = parseInt(star.dataset.v);
        document.getElementById('reviewRating').value = val;
        document.querySelectorAll('.star').forEach(s => {
            s.classList.toggle('active', parseInt(s.dataset.v) <= val);
        });
    };
});

async function submitReview() {
    const user    = getUser();
    const vkey    = document.getElementById('reviewVendorKey')?.value;
    const rating  = document.getElementById('reviewRating')?.value;
    const comment = document.getElementById('reviewComment')?.value.trim();
    if (!vkey) { showAlert('⚠️','Select a Vendor','Please select a vendor first.'); return; }

    const result = await apiFetch(`${API}/review/add`, {
        method: 'POST',
        body: JSON.stringify({ vendor: vkey, customer: user ? user.name : 'Anonymous', rating, comment })
    });
    if (result) {
        const msg = document.getElementById('reviewMsg');
        if (msg) { msg.innerText = `Review submitted! Avg rating: ${result.avgRating} ⭐`; msg.style.display = ''; }
        setTimeout(() => { if (msg) msg.style.display = 'none'; }, 3000);
    }
}

// Init customer dashboard
if (vendorGrid) {
    const user = getUser();
    if (user) {
        const el = document.getElementById('displayUserName');
        const gr = document.getElementById('welcomeGreeting');
        if (el) el.innerText = user.name;
        if (gr) gr.innerText = `Welcome, ${user.name}! 👋`;
    }
    renderVendors();
    refreshWalletDisplay();
    if (searchInput) searchInput.addEventListener('input', e => renderVendors(e.target.value));
}

// ── Vendor Dashboard (vendor-dashboard.html) ──────────────────────
const routeContainer = document.getElementById('vertical-route');
const orderContainer = document.getElementById('v-queue');
const departBtn      = document.getElementById('v-depart');
const reachBtn       = document.getElementById('v-reach');

let vendorKey  = null;

function showSection(name, el) {
    document.querySelectorAll('[id^="section-"]').forEach(s => s.classList.add('section-hidden'));
    const sec = document.getElementById('section-'+name);
    if (sec) sec.classList.remove('section-hidden');
    document.querySelectorAll('.v-nav li').forEach(li => li.classList.remove('active'));
    if (el) el.classList.add('active');
    if (name === 'orders') loadFullOrders();
}

async function loadVendorDashboard() {
    const user = getUser();
    if (!user || user.type !== 'vendor') return;
    vendorKey = user.vendorKey;

    const bizEl = document.getElementById('v-biz-name');
    const welEl = document.getElementById('v-welcome');
    const keyEl = document.getElementById('v-key-display');
    if (bizEl) bizEl.innerText = user.bizName || user.name;
    if (welEl) welEl.innerText = `Welcome, ${user.name}`;
    if (keyEl) keyEl.innerText = `Key: ${vendorKey}`;

    await refreshVendorStatus();
    await refreshOrders();
    await refreshVendorWallet();
    setInterval(async () => {
        await refreshOrders();
        await refreshVendorWallet();
        // Also refresh full orders list if that section is visible
        const sec = document.getElementById('section-orders');
        if (sec && !sec.classList.contains('section-hidden')) {
            await loadFullOrders();
        }
    }, 4000);
}

async function refreshVendorStatus() {
    if (!vendorKey) return;
    const v = await apiFetch(`${API}/vendor/status?vendor=${vendorKey}`);
    if (v && routeContainer) renderRoute(v);
}

function renderRoute(v) {
    routeContainer.innerHTML = '';
    (v.stops || []).forEach(stop => {
        const isActive = stop === v.currentStop;
        routeContainer.innerHTML += `
            <div class="route-stop ${isActive ? 'active' : ''}">
                <div class="stop-dot"></div>
                ${stop}
                ${isActive ? (v.status === 'IN-TRANSIT'
                    ? ' <small style="color:#ff9f43">(Departed)</small>'
                    : ' <small style="color:#2ecc71">(You are here)</small>') : ''}
            </div>`;
    });
}

async function refreshVendorWallet() {
    const walletEl = document.getElementById('v-wallet');
    if (!walletEl || !vendorKey) return;
    const w = await apiFetch(`${API}/wallet/balance?customer=${encodeURIComponent(vendorKey)}`);
    if (w) walletEl.innerText = w.balance;
}

async function refreshOrders() {
    if (!vendorKey || !orderContainer) return;
    const data = await apiFetch(`${API}/vendor/orders?vendor=${vendorKey}`);
    if (!data) return;
    const all = [...(data.pending || []), ...(data.ready || [])];
    const countEl = document.getElementById('order-count');
    if (countEl) countEl.innerText = all.length;

    orderContainer.innerHTML = '';
    if (all.length === 0) {
        orderContainer.innerHTML = "<p style='color:#888;padding:15px;text-align:center'>No active orders</p>";
        return;
    }
    all.forEach(o => {
        let actions = '';
        if (o.status === 'PENDING') {
            actions = `<div class="order-actions">
                <button class="btn-accept"  onclick="acceptOrder('${o.orderId}',true)">✓ Accept</button>
                <button class="btn-decline" onclick="acceptOrder('${o.orderId}',false)">✗ Decline</button>
            </div>`;
        } else if (o.status === 'ACCEPTED') {
            actions = `<div class="order-actions"><button class="btn-done" onclick="markReady('${o.orderId}')">🍽️ Mark Ready</button></div>`;
        } else if (o.status === 'READY') {
            actions = `<div class="order-actions"><button class="btn-collect" onclick="markCollected('${o.orderId}')">✅ Collected</button></div>`;
        }
        orderContainer.innerHTML += `
            <div class="q-item">
                <div class="q-item-header">
                    <span class="q-item-id">#${o.orderId.substring(0,8)}</span>
                    <span class="status-pill pill-${o.status}">${o.status}</span>
                </div>
                <div class="q-item-customer">${o.customer}</div>
                <div class="q-item-meta">${(o.items||[]).join(', ')}</div>
                <div class="q-item-bill">₹${o.bill} &nbsp;|&nbsp; 📍 ${o.location}</div>
                ${actions}
            </div>`;
    });
}

async function loadFullOrders() {
    if (!vendorKey) return;
    const data = await apiFetch(`${API}/vendor/orders?vendor=${vendorKey}`);
    if (!data) return;
    const renderList = (orders, containerId) => {
        const el = document.getElementById(containerId);
        if (!el) return;
        if (!orders.length) { el.innerHTML = "<p style='color:#888'>None</p>"; return; }
        el.innerHTML = orders.map(o => `
            <div class="q-item">
                <div class="q-item-header">
                    <span class="q-item-id">#${o.orderId.substring(0,8)}</span>
                    <span class="status-pill pill-${o.status}">${o.status}</span>
                </div>
                <div class="q-item-customer">${o.customer}</div>
                <div class="q-item-meta">${(o.items||[]).join(', ')}</div>
                <div class="q-item-bill">₹${o.bill} &nbsp;|&nbsp; 📍 ${o.location}</div>
            </div>`).join('');
    };
    renderList(data.pending || [], 'fullPendingList');
    renderList(data.ready   || [], 'fullReadyList');
}

async function acceptOrder(orderId, choice) {
    await apiFetch(`${API}/vendor/accept`, {
        method: 'POST',
        body: JSON.stringify({ vendor: vendorKey, orderId, choice: String(choice) })
    });
    await refreshOrders();
    const sec = document.getElementById('section-orders');
    if (sec && !sec.classList.contains('section-hidden')) await loadFullOrders();
}

async function markReady(orderId) {
    await apiFetch(`${API}/vendor/food_ready`, {
        method: 'POST',
        body: JSON.stringify({ vendor: vendorKey, orderId })
    });
    await refreshOrders();
    const sec = document.getElementById('section-orders');
    if (sec && !sec.classList.contains('section-hidden')) await loadFullOrders();
}

async function markCollected(orderId) {
    await apiFetch(`${API}/order/collect`, {
        method: 'POST',
        body: JSON.stringify({ vendor: vendorKey, orderId })
    });
    await refreshOrders();
    await refreshVendorWallet();
    const sec = document.getElementById('section-orders');
    if (sec && !sec.classList.contains('section-hidden')) await loadFullOrders();
}

if (departBtn) {
    departBtn.onclick = async () => {
        if (!confirm('Mark as DEPARTED from current stop?')) return;
        await apiFetch(`${API}/vendor/transit?vendor=${vendorKey}`);
        departBtn.style.display = 'none';
        reachBtn.style.display  = 'block';
        refreshVendorStatus();
    };
}
if (reachBtn) {
    reachBtn.onclick = async () => {
        if (!confirm('Have you REACHED the next stop?')) return;
        await apiFetch(`${API}/vendor/move?vendor=${vendorKey}`);
        reachBtn.style.display  = 'none';
        departBtn.style.display = 'block';
        refreshVendorStatus();
    };
}

if (routeContainer) loadVendorDashboard();
